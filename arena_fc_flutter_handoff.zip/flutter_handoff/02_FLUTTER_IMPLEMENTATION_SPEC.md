# Flutter 앱 구현 명세

## 1. 권장 기술 구성

기준: Flutter 3.x, Dart 3.x

권장 패키지:

```yaml
dependencies:
  flutter:
    sdk: flutter
  flutter_riverpod: ^2.0.0
  go_router: ^14.0.0
  dio: ^5.0.0
  freezed_annotation: ^2.0.0
  json_annotation: ^4.0.0
  cached_network_image: ^3.0.0
  flutter_secure_storage: ^9.0.0
  image_picker: ^1.0.0
  intl: ^0.19.0
  url_launcher: ^6.0.0
  path_provider: ^2.0.0

dev_dependencies:
  build_runner: ^2.0.0
  freezed: ^2.0.0
  json_serializable: ^6.0.0
  flutter_test:
    sdk: flutter
```

정확한 버전은 Flutter 프로젝트 생성 시점의 최신 호환 버전으로 맞춘다.

## 2. 권장 폴더 구조

```text
lib/
  app/
    app.dart
    router.dart
    theme.dart
  core/
    api/api_client.dart
    auth/auth_store.dart
    config/app_config.dart
    errors/app_exception.dart
    widgets/date_range_filter.dart
  features/
    dashboard/
      data/dashboard_repository.dart
      domain/dashboard.dart
      presentation/dashboard_screen.dart
    players/
      data/player_repository.dart
      domain/player.dart
      domain/player_stats.dart
      presentation/player_list_screen.dart
      presentation/player_detail_screen.dart
    matches/
      data/match_repository.dart
      domain/futsal_match.dart
      domain/match_player.dart
      presentation/match_list_screen.dart
      presentation/match_detail_screen.dart
    admin/
      data/admin_repository.dart
      presentation/login_screen.dart
      presentation/admin_screen.dart
      presentation/player_form_screen.dart
      presentation/match_form_screen.dart
      presentation/poster_manager_screen.dart
  main.dart
```

## 3. 라우팅

```text
/                         DashboardScreen
/players                  PlayerListScreen
/players/:id              PlayerDetailScreen
/matches                  MatchListScreen
/matches/:id              MatchDetailScreen
/admin/login              AdminLoginScreen
/admin                    AdminScreen
/admin/players/new        PlayerFormScreen
/admin/players/:id/edit   PlayerFormScreen
/admin/matches/new        MatchFormScreen
/admin/matches/:id/edit   MatchFormScreen
```

하단 NavigationBar 권장:

- 홈
- 선수
- 경기
- 관리자는 로그인 후 AppBar 메뉴 또는 별도 관리자 탭

## 4. Dart 모델

```dart
enum MatchStatus { inProgress, completed }
enum MatchResult { win, loss, draw }

class Player {
  final int id;
  final String name;
  final String? nickname;
  final String? profileImageUrl;
  final String position;
  final int? number;
  final bool isActive;
}

class PlayerStats {
  final int totalMatches;
  final int wins;
  final int losses;
  final int draws;
  final double winRate;
  final int goals;
  final int assists;
  final int mvpCount;
}

class MatchPlayer {
  final int id;
  final int matchId;
  final Player player;
  final String teamName;
  final MatchResult result;
  final int goals;
  final int assists;
  final bool isMvp;
}

class MatchPoster {
  final int id;
  final int matchId;
  final String imageUrl;
}

class FutsalMatch {
  final int id;
  final MatchStatus status;
  final DateTime matchDate;
  final String location;
  final String teamAName;
  final String teamBName;
  final int teamAScore;
  final int teamBScore;
  final String? winnerTeam;
  final String? memo;
  final List<MatchPlayer> matchPlayers;
  final List<MatchPoster> posters;
}
```

실제 구현에서는 Freezed + json_serializable을 권장한다. 서버의 `IN_PROGRESS`, `COMPLETED`, `WIN`, `LOSS`, `DRAW` 문자열을 Dart enum으로 변환하는 JsonKey converter가 필요하다.

## 5. 화면별 Flutter 요구사항

### DashboardScreen

- `RefreshIndicator`
- 최근 경기 카드
- 승률/MVP/득점/도움 TOP 5를 탭 또는 2열 카드로 표시
- 포스터는 가로 스크롤 또는 grid
- 포스터 선택 시 경기 상세 이동
- 날씨 카드

### PlayerListScreen

- 날짜 범위 선택
- 빠른 버튼: 전체/상반기/하반기
- 이름, 경기, 승/패/무, 승률, 득점, 도움, MVP 정렬
- 모바일에서는 카드형 목록
- 선수 선택 시 상세 이동

### PlayerDetailScreen

- 프로필, 이름, 닉네임, 포지션, 등번호
- 경기/승률/득점/도움/MVP StatCard
- 경기 이력 목록
- 경기 이력에 날짜, 스코어, 소속팀, 결과, 득점, 도움, MVP 표시

### MatchListScreen

- 날짜 범위와 빠른 버튼
- 날짜, 팀명, 스코어, 승리팀, MVP
- 선택 시 상세 이동

### MatchDetailScreen

- 경기 요약
- 양 팀 선수와 득점/도움/MVP
- 포스터 갤러리
- 메모

### MatchFormScreen

- 경기 날짜, 상태, 장소, 팀명
- 참가 선수 선택
- 같은 선수를 두 팀에 넣지 못하게 즉시 차단
- 수동 팀 선택 및 랜덤 균등 배정
- 득점 합산/점수 직접 입력 모드
- 팀별 선수 입력 영역
- 선수 득점 수 입력
- 득점 수만큼 골별 도움 선택 DropdownButton
- 도움 선택 후보는 같은 팀, 득점자 제외
- 팀별 다중 MVP 선택
- 메모
- 등록/수정 공통 화면으로 재사용

### AdminScreen

- 관리자 로그인 상태 확인
- 선수 CRUD
- 경기 CRUD
- 포스터 업로드/삭제
- Excel 및 분석 텍스트 다운로드 후 공유/열기

## 6. 날짜 범위

```dart
const allRange = (start: '2026-01-01', end: '2026-12-31');
const firstHalf = (start: '2026-01-01', end: '2026-05-31');
const secondHalf = (start: '2026-06-01', end: '2026-11-30');
```

- API에는 ISO `yyyy-MM-dd`로 전달
- 종료일은 서버에서 23:59:59.999까지 포함
- 빠른 버튼을 누르면 DatePicker 입력값도 같이 갱신

## 7. 상태관리

Riverpod 예시:

```text
authProvider
dashboardProvider
playerListProvider(DateRange)
playerDetailProvider(playerId)
matchListProvider(DateRange)
matchDetailProvider(matchId)
matchFormProvider(optionalMatchId)
```

- 조회: AsyncNotifier/Family
- 등록/수정/삭제 후 관련 provider invalidate
- 네트워크 오류, 빈 상태, 로딩 상태를 각각 표시

## 8. 인증

권장: 모바일용 Bearer access token.

```http
Authorization: Bearer <access-token>
```

- 토큰은 `flutter_secure_storage`에 저장
- 앱 시작 시 `/api/v1/auth/me`로 유효성 확인
- 401이면 로그인 화면으로 이동
- 관리자 기능은 UI 숨김만으로 끝내지 않고 API에서 반드시 403 차단
- 운영에서는 HTTPS 필수

기존 쿠키 인증을 유지하려면 Dio cookie manager를 쓸 수 있지만, 모바일에서는 Bearer token이 관리하기 쉽다.

## 9. 이미지 처리

- API가 `/uploads/...` 상대 경로를 반환하면 `BASE_URL + imageUrl`로 변환
- `cached_network_image`로 캐시 및 placeholder 처리
- 업로드는 multipart/form-data
- 이미지 선택 후 크기/형식 검증
- 서버 여러 대 운영 시 object storage 전환 권장

## 10. 환경 설정

```dart
class AppConfig {
  static const apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:3000',
  );
}
```

실행 예:

```bash
flutter run --dart-define=API_BASE_URL=http://192.168.0.10:3000
```

- Android Emulator에서 개발 PC localhost는 `10.0.2.2`
- iOS Simulator는 일반적으로 `127.0.0.1`
- 실기기는 PC의 LAN/Tailscale IP 사용

## 11. 테스트

- model JSON serialization 테스트
- 날짜 범위 provider 테스트
- 경기 payload validation 테스트
- 같은 선수 양 팀 중복 차단 테스트
- 도움 후보 같은 팀 제한 테스트
- MVP 후보 같은 팀 제한 테스트
- 관리자 401/403 처리 테스트
- Widget test: 선수 목록, 경기 상세, 경기 폼
- Integration test: 로그인 -> 선수 등록 -> 경기 등록 -> 수정 -> 삭제

