# Flutter 구현 체크리스트

## Phase 0. 백업과 기준 고정

- [ ] PostgreSQL 백업 생성
- [ ] 현재 Next.js 코드 commit/tag 생성
- [ ] `prisma/schema.prisma` 사본 보관
- [ ] 실제 `.env`와 비밀번호가 문서/Flutter asset에 없는지 확인
- [ ] 현재 웹의 주요 화면 캡처 보관

## Phase 1. 기존 Next.js에 모바일 API 추가

- [ ] `/api/v1/auth/login`
- [ ] `/api/v1/auth/me`
- [ ] Dashboard API
- [ ] Player list/detail/create/update/delete API
- [ ] Match list/detail/create/update/delete API
- [ ] Poster upload/delete API
- [ ] 날짜 범위 query 적용
- [ ] 골별 도움 payload 파싱 및 서버 집계
- [ ] API 공통 오류 형식
- [ ] API integration test

완료 기준: Postman/curl만으로 관리자 로그인, 선수 등록, 경기 등록/수정/삭제, 포스터 업로드까지 가능.

## Phase 2. Flutter 프로젝트 기반

- [ ] Flutter 프로젝트 생성
- [ ] Android/iOS application id 결정
- [ ] Riverpod, GoRouter, Dio 설정
- [ ] dev/prod API base URL 설정
- [ ] 공통 theme 구현
- [ ] 공통 loading/error/empty widget 구현
- [ ] JSON 모델 및 repository 구현

## Phase 3. 조회 화면

- [ ] 홈
- [ ] 선수 목록 및 정렬
- [ ] 선수 날짜 범위 필터
- [ ] 선수 상세
- [ ] 경기 목록 및 날짜 범위 필터
- [ ] 경기 상세
- [ ] 포스터 이미지 캐시/확대 보기
- [ ] Pull-to-refresh

## Phase 4. 관리자

- [ ] 로그인 및 secure token 저장
- [ ] 로그아웃
- [ ] 선수 등록/수정/비활성화/삭제
- [ ] 경기 등록/수정/삭제
- [ ] 수동 팀 선택
- [ ] 랜덤 팀 구성
- [ ] 득점 및 골별 도움 선택
- [ ] 다중 MVP 선택
- [ ] 포스터 업로드/삭제
- [ ] Excel/분석 텍스트 다운로드 및 공유

## Phase 5. 데이터 검증

- [ ] 웹과 Flutter의 선수 통계 동일
- [ ] 웹과 Flutter의 날짜 범위 결과 동일
- [ ] 득점 합계 동일
- [ ] 도움 합계 동일
- [ ] MVP 합계 동일
- [ ] 한 선수의 양 팀 중복 차단
- [ ] 다른 팀 도움 선수 차단
- [ ] 경기 삭제 cascade 확인
- [ ] 경기 기록 있는 선수 삭제 차단

## Phase 6. 배포 준비

- [ ] API HTTPS 적용
- [ ] `AUTH_SECRET` 강한 값 사용
- [ ] 관리자 비밀번호 재설정
- [ ] PostgreSQL 외부 노출 최소화
- [ ] Object Storage 검토
- [ ] Android release signing
- [ ] iOS signing/provisioning
- [ ] 개인정보 처리 및 앱 권한 문구 확인
- [ ] Crash reporting/logging 선택

## 권장 구현 순서

1. API 인증과 조회 API
2. Flutter 홈/선수/경기 조회
3. 관리자 선수 CRUD
4. 관리자 경기 CRUD
5. 골별 도움/MVP/랜덤 팀
6. 포스터 업로드
7. export 다운로드
8. 테스트 및 배포

## 완료 판단

Flutter 앱에서 다음 흐름이 가능해야 한다.

```text
앱 실행
-> 홈/선수/경기 조회
-> 날짜 필터 변경
-> 관리자 로그인
-> 선수 생성 및 포지션 수정
-> 경기 생성
-> 선수별 득점과 골별 도움 선택
-> 팀별 여러 MVP 선택
-> 포스터 업로드
-> 경기 수정/삭제
-> 통계와 랭킹 자동 반영
-> Excel/ChatGPT 분석 텍스트 다운로드
```

