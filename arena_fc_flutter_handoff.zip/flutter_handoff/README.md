# ARENA FC Flutter Handoff

이 폴더는 현재 Next.js 웹앱을 Flutter 앱으로 구현하기 위한 인수인계 자료다. Flutter 프로젝트로 옮길 때 이 폴더 전체를 복사하면 된다.

## 문서 순서

1. `01_CURRENT_WEBAPP_SPEC.md`: 현재 구현된 기능과 데이터 규칙
2. `02_FLUTTER_IMPLEMENTATION_SPEC.md`: Flutter 앱 구조, 화면, 패키지, 구현 방식
3. `03_BACKEND_API_REQUIREMENTS.md`: Flutter가 사용하려면 추가해야 할 REST API 계약
4. `04_MIGRATION_CHECKLIST.md`: 실제 구현 및 검증 순서
5. `05_DATABASE_SCHEMA.prisma`: 현재 DB 구조 참고용 스냅샷

## 가장 중요한 구조 결정

Flutter 앱은 PostgreSQL에 직접 접속하지 않는다.

```text
Flutter App
    |
    | HTTPS JSON API
    v
Next.js Backend (기존 프로젝트 확장)
    |
    | Prisma
    v
PostgreSQL
```

기존 Next.js 프로젝트를 API 서버로 유지하는 방식이 가장 빠르고 안전하다. Flutter에서 DB 주소와 비밀번호를 직접 사용하면 앱 패키지에서 자격 증명이 노출되고, 관리자 권한 및 데이터 검증을 우회할 수 있으므로 금지한다.

## 함께 옮기면 좋은 원본 자료

- 이 `flutter_handoff/` 폴더 전체
- `prisma/schema.prisma`: 최신 DB 모델 확인용
- `public/images/arena-team.jpg`: 홈 화면 팀 이미지
- `public/images/players/`: 현재 선수 프로필 이미지

`.env` 파일과 실제 DB 비밀번호, `AUTH_SECRET`은 복사하거나 Git에 올리지 않는다.
