# Flutter용 백엔드 API 요구사항

## 1. 기본 규칙

- Prefix: `/api/v1`
- Content-Type: `application/json; charset=utf-8`
- 날짜: ISO 8601
- 날짜 범위 query: `startDate=yyyy-MM-dd&endDate=yyyy-MM-dd`
- 성공 응답은 JSON 객체, 목록은 `items` 배열 사용
- 오류 형식 통일

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "같은 선수를 두 팀에 등록할 수 없습니다.",
    "fields": {}
  }
}
```

권장 HTTP 상태:

- 200 조회/수정 성공
- 201 생성 성공
- 204 삭제 성공
- 400 validation
- 401 로그인 필요
- 403 관리자 권한 없음
- 404 리소스 없음
- 409 중복/충돌
- 500 서버 오류

## 2. 인증 API

### `POST /api/v1/auth/login`

요청:

```json
{
  "username": "admin",
  "password": "user-input-password"
}
```

응답:

```json
{
  "accessToken": "...",
  "expiresIn": 28800,
  "admin": { "id": 1, "username": "admin" }
}
```

### `GET /api/v1/auth/me`

- Bearer token 필요

### `POST /api/v1/auth/logout`

- 서버 토큰 폐기 방식이면 구현

## 3. Dashboard API

### `GET /api/v1/dashboard`

응답 필드:

```json
{
  "recentMatches": [],
  "goalRankings": [],
  "assistRankings": [],
  "mvpRankings": [],
  "winRateRankings": [],
  "posters": [],
  "weather": null
}
```

랭킹 선수 공통 필드:

```json
{
  "id": 1,
  "name": "선수명",
  "profileImageUrl": null,
  "totalMatches": 10,
  "wins": 5,
  "losses": 3,
  "draws": 2,
  "winRate": 50.0,
  "goals": 8,
  "assists": 4,
  "mvpCount": 2
}
```

## 4. Player API

### `GET /api/v1/players`

Query:

- `startDate`
- `endDate`
- `activeOnly=true`
- 선택: `sort`, `order`

응답:

```json
{
  "range": { "startDate": "2026-01-01", "endDate": "2026-12-31" },
  "items": [
    {
      "id": 1,
      "name": "홍길동",
      "nickname": null,
      "profileImageUrl": null,
      "position": "미드필더",
      "number": 10,
      "isActive": true,
      "stats": {
        "totalMatches": 10,
        "wins": 5,
        "losses": 3,
        "draws": 2,
        "winRate": 50.0,
        "goals": 8,
        "assists": 4,
        "mvpCount": 2
      }
    }
  ]
}
```

### `GET /api/v1/players/{id}`

Query: 선택적으로 `startDate`, `endDate`

응답에 기본 정보, stats, matchHistory 포함.

### `POST /api/v1/players` 관리자

### `PUT /api/v1/players/{id}` 관리자

### `DELETE /api/v1/players/{id}` 관리자

삭제 시 경기 이력이 있으면 409 반환.

## 5. Match API

### `GET /api/v1/matches`

Query: `startDate`, `endDate`

### `GET /api/v1/matches/{id}`

응답 예:

```json
{
  "match": {
    "id": 10,
    "status": "COMPLETED",
    "matchDate": "2026-06-01T00:00:00.000Z",
    "location": "경기장",
    "teamAName": "회장팀",
    "teamBName": "총무팀",
    "teamAScore": 6,
    "teamBScore": 7,
    "winnerTeam": "총무팀",
    "memo": null,
    "matchPlayers": [],
    "posters": []
  }
}
```

### `POST /api/v1/matches` 관리자

### `PUT /api/v1/matches/{id}` 관리자

권장 요청 payload:

```json
{
  "matchDate": "2026-06-01",
  "status": "COMPLETED",
  "location": "경기장",
  "teamAName": "회장팀",
  "teamBName": "총무팀",
  "teamAScore": 6,
  "teamBScore": 7,
  "teamAPlayerIds": [1, 2, 3],
  "teamBPlayerIds": [4, 5, 6],
  "goalsByPlayerId": { "1": 2, "2": 1, "4": 3 },
  "goalAssistPlayerIdsByScorerId": {
    "1": [2, null],
    "2": [3],
    "4": [5, 6, null]
  },
  "chairmanTeamMvpIds": [1, 2],
  "managerTeamMvpIds": [4],
  "memo": "경기 메모"
}
```

백엔드는 `goalAssistPlayerIdsByScorerId`에서 선수별 도움 합계를 계산해야 한다. Flutter가 `assistsByPlayerId`를 직접 보내고 서버가 그대로 신뢰하면 안 된다.

검증:

- 선수 중복 금지
- 참가자 존재 확인
- 도움은 같은 팀이며 득점자 본인 제외
- 골 개수보다 많은 도움 선택 무시 또는 validation
- MVP는 해당 팀 선수
- score mode가 득점 합산이면 팀 득점 합과 점수 일치 확인 권장

### `DELETE /api/v1/matches/{id}` 관리자

관련 참가 기록과 포스터 DB 레코드 cascade 삭제. 실제 포스터 파일/object storage 객체도 함께 삭제.

## 6. Poster API

### `POST /api/v1/matches/{id}/posters` 관리자

- `multipart/form-data`
- field: `image`
- 이미지 MIME만 허용
- 최대 20MB

### `DELETE /api/v1/matches/{matchId}/posters/{posterId}` 관리자

### 이미지 URL 규칙

API는 가능하면 절대 URL 반환:

```json
{
  "id": 1,
  "imageUrl": "https://api.example.com/uploads/matches/10/file.jpg"
}
```

## 7. Export API

기존 기능을 `/api/v1` 아래로 감싸거나 현재 경로 유지 가능.

- `GET /api/export/matches`: `.xlsx`
- `GET /api/export/analysis-text`: `.txt`

Flutter에서는 Dio의 bytes 응답으로 받아 임시 디렉터리에 저장하고 share/open 처리.

## 8. 현재 API에서 반드시 수정할 점

1. 현재 `parseMatchJson`은 `goalAssistPlayerIdsByScorerId`를 읽지 않고 빈 객체로 만든다.
2. JSON API는 현재 클라이언트가 보낸 `assistsByPlayerId`를 그대로 사용한다.
3. Flutter API 구현 시 골별 도움 payload를 파싱하고 서버에서 도움 합계를 재계산해야 한다.
4. 모바일 인증용 login/me/token API가 없다.
5. 선수/경기 목록, 선수 상세, 경기 생성, 선수 CRUD, 포스터 API가 없다.
6. 포스터 URL은 현재 상대 경로다.

## 9. CORS 및 네트워크

- Flutter 네이티브 앱은 브라우저 CORS의 직접 대상은 아니지만 Flutter Web도 고려하면 허용 origin을 설정
- 운영 API는 HTTPS
- Android 개발에서 HTTP를 쓸 경우 network security config 필요할 수 있음
- iOS 개발에서 HTTP를 쓸 경우 ATS 예외 필요할 수 있음
- 운영에는 HTTP 예외를 남기지 않음

