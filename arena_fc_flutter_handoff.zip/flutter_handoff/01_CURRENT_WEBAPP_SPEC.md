# 현재 웹앱 기능 명세

## 1. 서비스 개요

- 서비스명: ARENA FC / ARENA Futsal Record
- 목적: 동호회 풋살 경기, 선수 기록, 랭킹, 경기 포스터 관리
- 현재 프론트엔드: Next.js 14 App Router + TypeScript + Tailwind CSS
- 현재 백엔드: Next.js Route Handler 및 Server Action
- ORM/DB: Prisma 6 + PostgreSQL
- 관리자: DB에 등록된 관리자 계정으로 로그인
- 일반 사용자는 조회만 가능

## 2. 현재 화면

### 홈 `/`

- 팀 히어로 영역
- 최근 경기 결과 5개
- 승률 TOP 5
- MVP TOP 5
- 득점 TOP 5
- 도움 TOP 5
- 전체 경기 포스터 갤러리
- 대구 10일 날씨. API 키가 없거나 호출 실패 시 mock 데이터 사용

### 선수 목록 `/players`

- 활성 선수만 표시
- 날짜 범위 내 기록만 집계
- 기본 범위: 2026-01-01 ~ 2026-12-31
- 빠른 범위
  - 전체: 2026-01-01 ~ 2026-12-31
  - 상반기: 2026-01-01 ~ 2026-05-31
  - 하반기: 2026-06-01 ~ 2026-11-30
- 표시 항목: 이름, 닉네임, 포지션, 등번호, 경기, 승, 패, 무, 승률, 득점, 도움, MVP
- 이름 및 모든 기록 항목 정렬

### 선수 상세 `/players/[id]`

- 프로필 이미지, 이름, 닉네임, 포지션, 등번호
- 경기 수, 승/패/무, 승률, 득점, 도움, MVP 누계
- 최근 경기 기록
  - 날짜
  - 경기 스코어
  - 해당 경기 소속팀
  - 결과
  - 득점
  - 도움
  - MVP 여부

### 경기 목록 `/matches`

- 선수 목록과 동일한 날짜 범위 필터 및 빠른 버튼
- 날짜, 스코어, 승리팀, 팀별 MVP 표시
- 경기 선택 시 상세 화면 이동

### 경기 상세 `/matches/[id]`

- 날짜, 장소, 스코어, 승리팀, 팀별 MVP
- 팀별 선수 목록
- 선수별 득점, 도움, MVP
- 경기 포스터 여러 장
- 경기 메모

### 관리자 로그인 `/abcd/login`

- DB의 `Admin` 레코드 확인
- 비밀번호는 PBKDF2-SHA512 해시로 검증
- 웹은 서명된 HttpOnly 쿠키 세션 사용
- 세션 만료: 8시간

### 관리자 `/abcd`

- 선수 등록, 수정, 삭제
- 경기 등록
- 등록된 선수/경기 목록
- 엑셀 다운로드
- ChatGPT 분석용 텍스트 다운로드

### 경기 수정 `/abcd/matches/[id]/edit`

- 경기의 모든 정보 수정
- 경기 삭제는 관리자 목록에서 수행
- 포스터 업로드 및 삭제

## 3. 선수 규칙

선수 필드:

- 이름: 필수
- 닉네임: 선택
- 프로필 이미지 URL: 선택
- 포지션: 필수 문자열
- 등번호: 선택
- 활성 여부

포지션 목록:

- 공격수
- 공격형미드필더
- 미드필더
- 수비형미드필더
- 윙백
- 풀백
- 센터백

기존 `FP`, `FW`, `MF`, `DF`, `GK` 값은 화면에서 기본 `미드필더`로 보정한다.

선수 삭제 규칙:

- 경기 참가 기록이 1건이라도 있으면 삭제 금지
- 이 경우 `isActive=false`로 선수 목록에서 제외

## 4. 경기 규칙

경기 상태:

- `IN_PROGRESS`: 경기 진행중
- `COMPLETED`: 결과 등록 완료

참가 결과:

- `WIN`
- `LOSS`
- `DRAW`

저장 검증:

- 양 팀에 최소 1명 필요
- 한 선수가 두 팀에 동시에 포함될 수 없음
- `matchId + playerId`는 unique
- MVP는 반드시 해당 팀 선수
- MVP는 팀별 0명 이상, 여러 명 가능
- 점수 비교로 참가 선수의 WIN/LOSS/DRAW와 승리팀 자동 계산
- 경기 삭제 시 MatchPlayer와 MatchPoster DB 레코드는 cascade 삭제

점수 입력 방식:

- 선수 득점 합산 모드
- 팀 점수 직접 입력 모드

도움 입력 방식:

- 숫자를 직접 입력하지 않음
- 득점 수만큼 각 골의 도움 선수를 선택
- 같은 팀 선수만 선택 가능
- 득점자 본인은 도움 선수로 선택 불가
- 도움 없음 선택 가능
- 현재 DB에는 골 이벤트 자체가 아니라 선수별 도움 합계만 `MatchPlayer.assists`에 저장됨
- 따라서 과거 경기의 특정 골-도움 연결은 완전히 복원할 수 없음

## 5. 통계 계산

별도 통계 테이블 없이 `MatchPlayer`를 실시간 집계한다.

- 경기 수: 참가 기록 수
- 승/패/무: result별 개수
- 승률: wins / totalMatches * 100, 소수점 1자리
- 득점: goals 합계
- 도움: assists 합계
- MVP: isMvp=true 개수
- 승률 랭킹은 1경기 이상 참가자만 포함
- 승률 동률 시 경기 수, 득점 순으로 정렬

## 6. 포스터와 이미지

- 경기별 포스터 여러 장
- DB에는 상대 경로만 저장: `/uploads/matches/{matchId}/{filename}`
- 실제 파일은 Next.js 서버의 `public/uploads/matches/`에 저장
- 파일 크기 제한: 20MB
- Flutter에서 표시할 때 API base URL을 붙여 절대 URL로 변환해야 함
- 서버가 여러 대라면 로컬 디스크 대신 S3/Naver Object Storage 같은 중앙 저장소 필요

## 7. 내보내기

관리자 전용:

- Excel `.xlsx`
  - 전체 경기 전적
  - 일별 경기 요약
  - 경기 History
  - 선수 통계
- ChatGPT 분석용 `.txt`
  - 분석 프롬프트
  - 선수별 통계
  - 경기별 팀 구성
  - 득점/도움/MVP
  - 간단 랭킹

## 8. 현재 DB 모델 요약

```text
Admin
  id, username, passwordHash, createdAt, updatedAt

Player
  id, name, nickname?, profileImageUrl?, position, number?, isActive
  createdAt, updatedAt

Match
  id, status, matchDate, location
  teamAName, teamBName, teamAScore, teamBScore
  winnerTeam?, chairmanTeamMvpId?, managerTeamMvpId?, memo?
  createdAt, updatedAt

MatchPlayer
  id, matchId, playerId, teamName, result
  goals, assists, isMvp, createdAt, updatedAt
  unique(matchId, playerId)

MatchPoster
  id, matchId, imageUrl, createdAt
```

중요: `chairmanTeamMvpId`, `managerTeamMvpId`는 과거 단일 MVP 호환용 대표값이며, 실제 다중 MVP 판단은 `MatchPlayer.isMvp`를 사용한다.

## 9. 현재 REST API 상태

현재 구현됨:

- `GET /api/matches/{id}`
- `PUT /api/matches/{id}` 관리자 쿠키 필요
- `DELETE /api/matches/{id}` 관리자 쿠키 필요
- `GET /api/export/matches` 관리자 쿠키 필요
- `GET /api/export/analysis-text` 관리자 쿠키 필요

대부분의 등록/수정 기능은 Next.js Server Action이라 Flutter에서 직접 호출할 수 없다. Flutter 개발 전에 `03_BACKEND_API_REQUIREMENTS.md`의 API를 먼저 추가해야 한다.

